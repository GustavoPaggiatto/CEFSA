﻿using Domain.Entities;
using Infra.Repository;

namespace Application.UseCases
{
    public sealed class DeleteEstoqueItem
    {
        readonly EstoqueItemRepository _repository;

        public DeleteEstoqueItem()
        {
            _repository = new EstoqueItemRepository();
        }

        public void Delete(EstoqueItem estoqueItem)
        {
            _repository.Delete(estoqueItem);
        }
    }
}

﻿using Domain.Entities;
using Infra.Repository;

namespace Application.UseCases
{
    public sealed class UpdateEstoqueItem
    {
        readonly EstoqueItemRepository _repository;

        public UpdateEstoqueItem()
        {
            _repository = new EstoqueItemRepository();
        }

        public void Update(EstoqueItem estoqueItem)
        {
            _repository.Update(estoqueItem);
        }
    }
}

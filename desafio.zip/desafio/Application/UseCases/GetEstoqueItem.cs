﻿using Domain.Entities;
using Infra.Repository;
using System.Collections.Generic;

namespace Application.UseCases
{
    public sealed class GetEstoqueItem
    {
        readonly EstoqueItemRepository _repository;

        public GetEstoqueItem()
        {
            _repository = new EstoqueItemRepository();
        }

        public IEnumerable<EstoqueItem> Get()
        {
            return _repository.Get();
        }
    }
}

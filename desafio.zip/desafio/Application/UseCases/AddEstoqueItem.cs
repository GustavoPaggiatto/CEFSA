﻿using Domain.Entities;
using Infra.Repository;

namespace Application.UseCases
{
    public sealed class AddEstoqueItem
    {
        EstoqueItemRepository _repository;
        
        public AddEstoqueItem()
        {
            _repository = new EstoqueItemRepository();
        }

        public void Add(EstoqueItem estoqueItem)
        {
            _repository.Add(estoqueItem);
        }
    }
}

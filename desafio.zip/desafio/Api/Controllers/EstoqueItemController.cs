﻿using Application.UseCases;
using Domain.Entities;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Api.Controllers
{
    [ApiController]
    [Route("estoqueItem")]
    public class EstoqueItemController : ControllerBase
    {
        [HttpPost]
        [Route("post")]
        public IActionResult Post([FromBody] EstoqueItem estoqueItem)
        {
            try
            {
                var useCaseService = new AddEstoqueItem();
                useCaseService.Add(estoqueItem);

                return StatusCode(201, new { Id = estoqueItem.Id });
            }
            catch (Exception ex)
            {
                return StatusCode(500, ex.Message);
            }
        }

        [HttpPut]
        [Route("put")]
        public IActionResult Put([FromBody] EstoqueItem estoqueItem)
        {
            try
            {
                var useCaseService = new UpdateEstoqueItem();
                useCaseService.Update(estoqueItem);

                return StatusCode(204);
            }
            catch (Exception ex)
            {
                return StatusCode(500, ex.Message);
            }
        }


        [HttpPut]
        [Route("delete")]
        public IActionResult Delete([FromBody] EstoqueItem estoqueItem)
        {
            try
            {
                var useCaseService = new DeleteEstoqueItem();
                useCaseService.Delete(estoqueItem);

                return StatusCode(204);
            }
            catch (Exception ex)
            {
                return StatusCode(500, ex.Message);
            }
        }


        [HttpGet]
        [Route("get")]
        public IActionResult Get()
        {
            try
            {
                var useCaseService = new GetEstoqueItem();
                return StatusCode(200, useCaseService.Get());
            }
            catch (Exception ex)
            {
                return StatusCode(500, ex.Message);
            }
        }
    }
}

﻿using Domain.Entities;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;

namespace Infra.Repository
{
    public sealed class EstoqueItemRepository
    {
        readonly string _connectionString;

        public EstoqueItemRepository()
        {
            _connectionString = "Server=localhost\\SQLEXPRESS;Database=DesafioDois;Trusted_Connection=True;";
        }

        public void Add(EstoqueItem estoqueItem)
        {
            using (var connection = new SqlConnection(_connectionString))
            {
                connection.Open();

                var command = connection.CreateCommand();

                command.Parameters.AddWithValue("@itemId", estoqueItem.Item.Id);
                command.Parameters.AddWithValue("@dataEntrada", estoqueItem.DataEntrada);
                command.Parameters.AddWithValue("@localCompra", estoqueItem.LocalCompra);
                command.Parameters.AddWithValue("@valorPago", estoqueItem.ValorPago);

                command.CommandText = "insert into EstoqueItem values(@itemId,@dataEntrada,@localCompra,@valorPago)";

                command.ExecuteNonQuery();
            }
        }

        public void Update(EstoqueItem estoqueItem)
        {
            using (var connection = new SqlConnection(_connectionString))
            {
                connection.Open();

                var command = connection.CreateCommand();

                command.Parameters.AddWithValue("@id", estoqueItem.Id);
                command.Parameters.AddWithValue("@itemId", estoqueItem.Item.Id);
                command.Parameters.AddWithValue("@dataEntrada", estoqueItem.DataEntrada);
                command.Parameters.AddWithValue("@localCompra", estoqueItem.LocalCompra);
                command.Parameters.AddWithValue("@valorPago", estoqueItem.ValorPago);

                command.CommandText = "update EstoqueItem set dataEntrada=@dataEntrada, localCompra=@localCompra, valorPago=@valorPago where id=@id";

                command.ExecuteNonQuery();
            }
        }

        public void Delete(EstoqueItem estoqueItem)
        {
            using (var connection = new SqlConnection(_connectionString))
            {
                connection.Open();

                var command = connection.CreateCommand();

                command.Parameters.AddWithValue("@id", estoqueItem.Id);

                command.CommandText = "delete from EstoqueItem where id=@id";

                command.ExecuteNonQuery();
            }
        }

        public IEnumerable<EstoqueItem> Get()
        {
            var estoqueItems = new List<EstoqueItem>();

            using (var connection = new SqlConnection(_connectionString))
            {
                connection.Open();

                var command = connection.CreateCommand();
                command.CommandText = "select * from EstoqueItem";

                var adapter = new SqlDataAdapter(command);
                var dataTable = new DataTable();

                adapter.Fill(dataTable);

                for(var i = 0; i < dataTable.Rows.Count; i++)
                {
                    DataRow row = dataTable.Rows[i];

                    estoqueItems.Add(
                        new EstoqueItem(
                            null,
                            Convert.ToDateTime(row["dataEntrada"]),
                            row["localCompra"].ToString(),
                            Convert.ToDouble(row["valorPago"])));
                }
            }

            return estoqueItems;
        }
    }
}

﻿using Domain.ValueObjects;

namespace Domain.Entities
{
    public sealed class Item : BaseEntity<int>
    {
        public TipoItem Tipo { get; private set; }
        public TamanhoItem Tamanho { get; private set; }
        public string Marca { get; private set; }
        public string Descricao { get; private set; }
        public string Cor { get; private set; }

        public Item(TipoItem tipo, TamanhoItem tamanho, string marca, string descricao, string cor)
        {
            this.SetTipo(tipo);
            this.SetTamanho(tamanho);
            this.SetMarca(marca);
            this.SetDescricao(descricao);
            this.SetCor(cor);
        }

        public void SetTipo(TipoItem tipo) => this.Tipo = tipo;
        public void SetTamanho(TamanhoItem tamanho) => this.Tamanho = tamanho;
        public void SetMarca(string marca) => this.Marca = marca;
        public void SetDescricao(string descricao) => this.Descricao = descricao;
        public void SetCor(string cor) => this.Cor = cor;
    }
}

﻿using System;

namespace Domain.Entities
{
    public sealed class EstoqueItem : BaseEntity<int>
    {
        public Item Item { get; private set; }
        public DateTime DataEntrada { get; private set; }
        public string LocalCompra { get; private set; }
        public double ValorPago { get; private set; }
        public double Preco { get { return this.ValorPago * 2; } }

        public EstoqueItem(Item item, DateTime dataEntrada, string localCompra, double valorPago)
        {
            this.SetItem(item);
            this.SetDataEntrada(dataEntrada);
            this.SetLocalCompra(localCompra);
            this.SetValorPago(valorPago);
        }

        public void SetItem(Item item) => this.Item = item;
        public void SetDataEntrada(DateTime dataEntrada) => this.DataEntrada = dataEntrada;
        public void SetLocalCompra(string localCompra) => this.LocalCompra = localCompra;
        public void SetValorPago(double valorPago) => this.ValorPago = valorPago;
    }
}

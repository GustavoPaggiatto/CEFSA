﻿namespace Domain.ValueObjects
{
    public enum TamanhoItem
    {
        P,
        M,
        G,
        GG,
        XG
    }
}

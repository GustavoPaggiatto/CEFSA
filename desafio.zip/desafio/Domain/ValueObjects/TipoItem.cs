﻿namespace Domain.ValueObjects
{
    public enum TipoItem
    {
        Vestido,
        Saia,
        Calca,
        Outros
    }
}

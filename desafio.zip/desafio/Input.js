const btnRegister = document.querySelector('#btnRegister');
btnRegister.addEventListener('Click', () => {

    const DataCompra = document.querySelector('#DataCompra');
    const Tipo = document.querySelector('#Tipo');
    const LocalCompra = document.querySelector('#LocalCompra');
    const ValorCompra = document.querySelector('#ValorCompra');
    const Item = document.querySelector('#Item');

    let xhr = new XMLHttpRequest();
    
    // open() method to pass request
    // type, url and async true/false 
    xhr.open('POST',
        '/EstoqueItem/Post', true);
    
    // Setting content-type
    xhr.getResponseHeader('Content-type', 'application/json');
    
    // Perform the following when the response is ready
    xhr.onload = function () {
        if (this.status === 200) {
            console.log(this.responseText)
        }
        else {
            console.log("Some error occured")
        }
    }
    
    // Send the request as an object obj
    obj = {
            item: Item.value,
            Tipo: Tipo.value,
            DataCompra: DataCompra.value,
            ValorCompra: ValorCompra.value,
            LocalCompra: LocalCompra.value
            };
    xhr.send(JSON.parse(obj));
})

(() => {
        const Item = document.querySelector('#Item'); 

         // Instantiating new XMLHttpRequest() method
        let xhr = new XMLHttpRequest();
        
        // open() method to pass request
        // type, url and async true/false 
        xhr.open('GET',
            '/EstoqueItem/Get', true);
        
        // onload function to get data 
        xhr.onload = function () {
            if (this.status === 200) {
                const itens = JSON.parse(this.responseText);
                itens.forEach(element => {
                    let opt = document.createElement('option');
                    opt.value = element;
                    Item.appendChild(opt);        
                });
            }
        }
        // Send function to send data
        xhr.send()
        })()